
This was a presentation for PyCon 2008 on how to understand Unicode in Python.
It is in the public domain under the `WTFPL`_ license.
It is free to re-use / re-write or anything you want.

The source of the text is contained in unicode.txt

To build the slides create a virtualenv and run::

  pip install -r requirements.txt
  python build.py


.. _`WTFPL`: http://www.wtfpl.net/about/
